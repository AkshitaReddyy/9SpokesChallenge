# 9Spokes DevSecOps Challenge

## Create EKS Cluster in AWS

```bash
$ cd terraform
$ terraform init
$ terraform plan
$ terraform apply
```

## Create staging namespace using kubectl

```bash
$ aws eks update-kubeconfig --name 9spokes-eks-cluster --region us-east-1
$ kubectl create namespace staging
```

## Build docker image

```bash
$ cd hello
$ docker build -t <username>/hello:latest .
```

## Push docker image to docker hub

```bash
$ docker login -u username -p password
$ docker push <username>/hello:latest
```
## Single Pod

```bash
$ cd k8s
$ kubectl apply -f single-pod.yaml
```

### Multi-node

```bash
$ cd k8s
$ kubectl apply -f multinode.yaml
```

### Multi-container Pod

```bash
$ cd k8s
$ kubectl apply -f multi-container.yaml
```

### Alertmanaget & Grafana

```bash
$ cd k8s
$ helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
$ helm install prometheus prometheus-community/prometheus -n kube-system
$ helm repo add grafana https://grafana.github.io/helm-charts
$ helm install grafana grafana/grafana -n kube-system
$ kubectl apply -f ingress.yaml -n kube-system
$ kubectl apply -f ingress.yaml -n kube-system
$ kubectl apply -f alertmanager.yaml -n kube-system
$ kubectl apply -f alert.yaml -n kube-system
```
